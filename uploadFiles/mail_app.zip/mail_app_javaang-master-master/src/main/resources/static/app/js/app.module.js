var app = angular.module("mail-app",
    [
        'ngRoute',
        'ngResource',
        'ui.bootstrap'
    ]);

    app.config(function($routeProvider, $locationProvider){
        $locationProvider.html5Mode(true);

        $routeProvider
            .when('/login', {
                template: '<login></login>'
            })
            .when('/register', {
                template: '<register></register>'
            })
            .when('/', {
                template: '<login></login>'
            })
            .when('/inbox', {
                template: '<inbox></inbox>'
            })
            .when('/send-mail', {
                template: '<send-mail></send-mail>'
            })
            .when('/trash', {
                template: '<trash></trash>'
            })
            .when('/mail-content/:id', {
                template: '<mail-content></mail-content>'
            })
            .otherwise({
                redirectTo: '/'
            });
    })

    app.factory('AccountApi', ['$resource', function($resource){
        var baseUrl = "/user"

        return $resource('/', { }, {
            login: {
                method: 'POST',
                url: baseUrl + '/login'
            },
            register: {
                method: 'POST',
                url: baseUrl + '/register'
            }
        });
    }]);

    app.factory('MailApi', ['$resource', function($resource) {
        var baseUrl = "/mail"

        return $resource('/:id', { id: '@id' }, {
            list: {
                method: 'GET',
                url: baseUrl + '/inbox',
                isArray: true
            },
            send: {
                method: 'POST',
                url: baseUrl + '/send-mail'
            },
            read: {
                method: 'GET',
                url: baseUrl + '/mail-content/:id'
            },
            delete: {
                method: 'DELETE',
                url: baseUrl + '/delete'
            } 
        })
    }])

    app.factory('AccountService', function() {
        let user;
        let loggedIn = false;
        let observers = [];

        function setUser(user1) {
            user = user1;
        }

        function getUser() {
            return user;
        }

        function getLoggedIn() {
            return loggedIn;
        }

        function setLoggedIn() {
            loggedIn = l;
            for(let i = 0; i < observers.length; i++) {
                observers[i](l);
            }
        }

        function addObserver(o) {
            observers.push(o);
        }

        return {
            setL : setLoggedIn,
            gelL : getLoggedIn,
            addO : addObserver,
            setU : setUser,
            getU : getUser
        }
    });