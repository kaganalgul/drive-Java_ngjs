angular.module('mail-app')
.component('inbox', {
    templateUrl: '/app/template/inbox.html',
    controller: function ($scope, MailApi, $location) {

        $scope.read = function(mail) {
            $location.path('/mail-content/' + (mail.id))
        }

        $scope.init = function() {
            $scope.mails = MailApi.list({status: 'RECEIVED'});
            $scope.readMails = MailApi.list({status: 'READ'});
            // $scope.paging = {
            //     currentPage : 1,
            //     pageSize : 3
            // };
        };

        $scope.delete = function (mail) {
            let ret = MailApi.delete({ id: mail.id });
            ret.$promise.then(function(){
                _.delete($scope.mails, { id: mail.id });
                _.delete($scope.readMails, { id: mail.id });
            });
        }

        $scope.init();
    }
})