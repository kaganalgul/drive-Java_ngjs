package com.beam.mail_application.model;

public enum Status {
    DELETED,SPAM,READ,RECEIVED
}
