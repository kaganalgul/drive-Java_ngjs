package com.beam.drive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriveApplicationTests {

	@Test
	void contextLoads() {
	}

}
