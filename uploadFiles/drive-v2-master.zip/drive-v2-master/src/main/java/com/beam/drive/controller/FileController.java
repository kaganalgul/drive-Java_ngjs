package com.beam.drive.controller;

import com.beam.drive.dto.FileUploadResponse;
import com.beam.drive.service.FileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.IOException;

@RequiredArgsConstructor
@RestController
@RequestMapping("file")
public class FileController {

    private final FileService fileService;

    @PostMapping("upload")
    public void upload(@RequestPart MultipartFile file, HttpSession session) throws IOException {

        String filename = StringUtils.cleanPath(file.getOriginalFilename());
        long size = file.getSize();

        fileService.upload(session, file);

        //FileUploadResponse response = new FileUploadResponse();
        //response.setFilename(filename);
        //response.setSize(size);
        //response.setDownloadUri("/downloadFile");
    }

    @PostMapping("read")
    public void read(){

    }
}
