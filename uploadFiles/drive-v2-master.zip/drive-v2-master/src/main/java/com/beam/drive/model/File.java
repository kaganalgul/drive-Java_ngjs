package com.beam.drive.model;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.*;

@Data
@TypeAlias("File")
@Accessors(chain = true)
@Document(collection = "File")
public class File extends Base {
    private String name;
    private String owner;
    private Date createDate = new Date();
    private Status status = Status.UPLOAD;
    private long size;
}
