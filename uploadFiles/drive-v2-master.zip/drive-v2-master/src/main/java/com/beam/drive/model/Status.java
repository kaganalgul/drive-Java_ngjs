package com.beam.drive.model;

public enum Status {
    SHARE, DELETE, UPLOAD
}
