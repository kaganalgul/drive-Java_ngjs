package com.beam.drive.service;

import com.beam.drive.model.File;
import com.beam.drive.model.User;
import com.beam.drive.repository.FileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import static com.beam.drive.service.UserService.SESSION_ACCOUNT;

@Service
@RequiredArgsConstructor
public class FileService {
    private final FileRepository fileRepository;

    @Value("${base.path}")
    private String basePath;

    public void upload1(HttpSession session, MultipartFile file, String filename) throws IOException {
        User user = (User) session.getAttribute(SESSION_ACCOUNT);

        File newFile = new File()
                .setOwner(user.getEmail())
                .setName(file.getOriginalFilename());

        user.getMyFiles().add(newFile);

        Path uploadDirectory = Paths.get("Files-Upload");

        InputStream inputStream = file.getInputStream(); // inputStream -> verileri byte cinsinden okumamızı sağlar.
        Path filePath = uploadDirectory.resolve(filename); // resolve -> string i path e çevirmemizi sağlar.
        Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING); // Files.copy -> byte'ları bir dosyaya aktarmaya ya da tam tersi için kullanılır.


        fileRepository.save(newFile);
    }

    public void upload(HttpSession session, MultipartFile file) throws IllegalStateException, IOException {
        User user = (User) session.getAttribute(SESSION_ACCOUNT);

        File newFile = new File()
                .setOwner(user.getEmail())
                .setName(file.getOriginalFilename());

        user.getMyFiles().add(newFile);
        file.transferTo(new java.io.File("C:\\Users\\kagan\\Desktop\\" + file.getOriginalFilename()));

        fileRepository.save(newFile);
    }

    public byte[] read(String filename) throws IOException {
        Path path = Paths.get(basePath + filename);
        if (path.toFile().exists()) {
            return Files.readAllBytes(path);
        } else {
            return null;
        }
    }
}
