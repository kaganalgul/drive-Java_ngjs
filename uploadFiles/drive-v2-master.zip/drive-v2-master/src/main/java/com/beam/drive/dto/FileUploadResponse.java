package com.beam.drive.dto;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class FileUploadResponse {
    private String filename;
    private String downloadUri;
    private long size;
}
