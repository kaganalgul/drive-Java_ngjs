package com.beam.drive.model;

import lombok.Data;
import org.springframework.data.annotation.Id;

import java.util.UUID;

@Data
public class Base {

    @Id
    private String id = UUID.randomUUID().toString();
}
