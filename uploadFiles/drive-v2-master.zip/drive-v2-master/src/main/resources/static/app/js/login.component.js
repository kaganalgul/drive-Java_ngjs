angular.module('drive-app')
    .component('login', {
        templateUrl: '/app/template/login.html',
        controller: function($scope, $routeParams, AccountApi, $location) {

            $scope.login = function() {
                AccountApi.login($scope.loginRequest, function (authenticationResponse) {
                    if (authenticationResponse.code == 0) {
                        $location.path("/home");
                    } else {
                        switch(authenticationResponse.code){
                            case -1:
                                toastr.info("password incorrect")
                                break;
                            case 1:
                                toastr.error("user not found");
                                break;
                        }
                    }
                });
            }

            $scope.init = function () {
                $scope.loginRequest = { };
            };

            $scope.init();
        }
    })