angular.module('drive-app')
.component('home', {
    templateUrl: '/app/template/home.html',
    controller: function($scope, FileApi, $location) {

        $scope.upload = function() {
            FileApi.upload({file: $scope.file}, 
                function() {
                $location.path('/home')
            })
        };
            
        $scope.init = function(){
        };

        $scope.init();
    }
})