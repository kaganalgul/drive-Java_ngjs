var app = angular.module("drive-app",
    [
        'ngRoute',
        'ngResource'
    ]);

    app.config(function($routeProvider, $locationProvider) {
        $locationProvider.html5Mode(true);

        $routeProvider
            .when('/login', {
                template: '<login></login>'
            })
            .when('/register', {
                template: '<register></register>'
             })
             .when('/home', {
                template: '<home></home>'
             })
            .otherwise({
                rediretTo: '/'
            })
    })

    app.factory('AccountApi', ['$resource', function($resource) {
        var baseUrl = '/user';

        return $resource('/', { }, {
            login: {
                method: 'POST',
                url: baseUrl + '/login'
            },
            register: {
                method: 'POST',
                url: baseUrl + '/register'
            }
        })
    }])

    app.factory('FileApi', ['$resource', function($resource) {
        var baseUrl= '/file';

        return $resource('/file/:id', { id: '@id' }, {
            upload: {
                method: "POST",
                url: baseUrl + "/upload",
                transformRequest: function (data) {
                    let file = data.file;
                    var fd = new FormData();
                    fd.append("file", file);
                    return fd;
    
                },
                headers: { "Content-Type": undefined }
            }
        })
    }])